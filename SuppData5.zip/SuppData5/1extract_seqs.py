# -*- coding: utf-8 -*-
"""
Created on Thu May 25 17:30:39 2023

@author: Sasha
"""

import sys, os
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio.Alphabet import generic_dna
from Bio.Alphabet import IUPAC
from Bio.Blast import NCBIXML

def translate_upstream(NTseq, bNTseq):
    AAseq = bNTseq.translate()
    for i in [0,1,2]:
        fAAseq = NTseq[i:].translate()
        if AAseq in fAAseq:
            break
    return fAAseq

def alignfAA(fAA, bAA):
    st = '-'*fAA.index(bAA)
    endstring = '-'*(len(fAA)-len(bAA+st))
    nbaa = st+bAA+endstring
    return nbaa

def trimfAA(fAA, bAA):
    stAA = str(fAA)
    startstring = stAA[:fAA.index(bAA)]
    if '*' in startstring:
        startstring = stAA[:fAA.index(bAA)].split('*')[-1]
    if 'M' in startstring:
        startstring = 'M'+'M'.join(startstring.split('M')[1:])
    endstring = str(fAA[fAA.index(bAA)+len(bAA):]).split('*')[0]
    return startstring+bAA+endstring
    
rblast = open('E:\\Dropbox\\Conus virgo\\virgodata\\annotation_file_blastx_DB15_output', 'r')

IDs = []
hits = {}
for line in rblast:
    data = line.strip().split('\t')
    if float(data[2]) >= 60 and not data[0] in IDs:
        IDs.append(data[0])
        hits[data[0]] = [int(data[6]),int(data[7])]
rblast.close()

print len(IDs)
for thing in IDs[:5]:
    print thing, hits[thing]

seqs = {}
trinity = open('E:\\Dropbox\\Conus virgo\\virgodata\\Trinity.fasta', 'r')
for line in trinity:
    line= line.strip()
    if line.startswith('>'):
        ID = line[1:].split()[0]
        if ID in IDs:
            seqs[ID] = trinity.next().strip()
trinity.close()
print len(seqs)

AAf = open('E:\\Dropbox\\Conus virgo\\virgodata\\blastx_DB15_AA_seqs.txt', 'w')
NTseqs = {}
AAseqs = {}
for k in IDs:
    if hits[k][0] < hits[k][1]:
        NTseq = Seq(seqs[k], IUPAC.unambiguous_dna)
        bNTseq = NTseq[hits[k][0]-1:hits[k][1]]
    else:
        NTseq = Seq(seqs[k], IUPAC.unambiguous_dna).reverse_complement()
        bNTseq = Seq(seqs[k][hits[k][1]-1:hits[k][0]], IUPAC.unambiguous_dna).reverse_complement()
        
    bAAseq = bNTseq.translate()
    #print k, bAAseq
    complete = False
    if bAAseq[0] == 'M':
        complete = True
    fAAseq = translate_upstream(NTseq, bNTseq)
    # Now if there is a stop upstream or downstream the BLASTED region, we trim the full seq and return the trimmed one
    #print bNTseq, bAAseq, hits[k]
    #print fAAseq
    AAseq = trimfAA(fAAseq, bAAseq)
    print >> AAf, k+'\t'+str(bNTseq)+'\t'+str(bAAseq)+'\t'+str(AAseq)
AAf.close()
    
    
    #print >>AAf, k+'\t'+hits[k]+'\t'+seqs[k]+'\t'+bNTseq+'\t'+


