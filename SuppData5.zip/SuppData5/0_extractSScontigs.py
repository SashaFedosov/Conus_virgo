# -*- coding: utf-8 -*-
"""
Created on Fri May 26 10:15:09 2023

@author: Sasha
"""

import sys, os
TIDs = []
SignalP = open('E:\\Dropbox\\Conus virgo\\virgodata\\signalP_allORFtab', 'r')
for line in SignalP:
    data = line.strip().split('\t')
    if data[1].startswith('SP') and data[-1].replace(' ','').split(':')[-1].startswith('0') and float(data[-1].replace(' ','').split(':')[-1]) >= 0.6:
        TID = data[0][data[0].index('TRINITY'):].split(':')[0]
        TIDs.append(TID)
SignalP.close()
print len(TIDs)
print TIDs[0]

seqs = {}
trinity = open('E:\\Dropbox\\Conus virgo\\virgodata\\Trinity.fasta', 'r')
wf = open('E:\\Dropbox\\Conus virgo\\virgodata\\Cvirgo_secreted_transcripts.fasta', 'w')
for line in trinity:
    line= line.strip()
    if line.startswith('>'):
        ID = line[1:].split()[0]
        if ID in TIDs:
            print >>wf, '>'+ID+'\n'+trinity.next().strip()
trinity.close()
wf.close() 