import sys, os

Sp = sys.argv[1]
Dvalue = 0.6
ORFile = Sp+'.allORFs.fasta'

#ORFile = Sp+'.NIORFs.fasta'
# Split ORF file into sub-datasets, each with 250000 ORFs to avoid signalP hangups
cmd1 = 'split -l 500000 -d '+ORFile
#os.system(cmd1)

# Rename the sub-datasets
cmd2 = 'mmv x0\* '+Sp+'_splitORFs\#1'
#os.system(cmd2)

# Run signalP on each sub-dataset
filelist = os.listdir('.')
for item in filelist:
    if Sp+'_splitORFs' in item and not 'signalp5' in item:
        counter = item[-1]
        print '\nRunning signalP on '+item+'...'
        cmd3 = 'signalp -fasta '+item+' -org euk -format short -verbose -batch 40000'
        #os.system(cmd3)
# merge summary files
cmd4 = 'cat *_summary.signalp5 > '+Sp+'_allORFs.signalp'
#os.system(cmd4)
cmd41 = 'rm *_summary.signalp5 '+Sp+'_splitORFs*'
#os.system(cmd41)

# Pick up ORFs with a signal sequence. ### revise the script, it should take 5 agrs: 1-sigP-summary-file, 3-Dvalue, 4-output-ORFSfasta, 5-output=SinalSeqs.fasta
print '\nParsing signalP results...'
cmd5 = 'python 3pick_signalP_ORFs.py '+Sp+'_allORFs.signalp '+Sp+'.allORFs.fasta '+str(Dvalue) + ' '+Sp+'_sigORFs.fasta '+Sp+'_SSeqs.fasta'
#cmd5 = 'python 3pick_signalP_ORFs.py '+Sp+'_allORFs.signalp '+Sp+'.NIORFs.fasta '+str(Dvalue) + ' '+Sp+'_sigORFs.fasta '+Sp+'_SSeqs.fasta'
#os.system(cmd5)

# Run phobius on SigORFs.fasta
print '\nRunning phobius...'
cmd6 = 'phobius '+Sp+'_sigORFs.fasta > '+Sp+'.phobius.out 2> '+Sp+'.phobius.err'
#os.system(cmd6)

# Read the phobius output and filter the SigORFs.fasta to remove ORFs with transmembrane domains. ### revise the script, it should take 3 agrs: 1-phobius-output, 2-SigORFs-file, 3-output-final-ORFSfasta
print '\nParsing phobius results...'
cmd7 = 'python 3parse_phobius.py '+Sp+'.phobius.out '+Sp+'_sigORFs.fasta '+Sp+'_finalORFs.fasta'
#os.system(cmd7)

# Run HMMER annotation on the filtered ORFs
print '\nRunning HMMER...'
cmd8 = 'hmmsearch --cut_ga --cpu 8 --tblout '+Sp+'HMMER_output1_tbl.out --domtblout '+Sp+'HMMER_output2_dtbl.out Pfam-A.hmm '+Sp+'_finalORFs.fasta > '+Sp+'_log_hmm.out'
#os.system(cmd8)

# Filter HMMER results
cmd9 = 'python 3filter_redundant_HMMER_targets.py '+Sp+'HMMER_output1_tbl.out '+Sp+'HMMER_output1_tblF.out'
#os.system(cmd9)

cmd10 = 'python 3filter_redundant_HMMER_domains.py '+Sp+'HMMER_output2_dtbl.out '+Sp+'HMMER_output2_dtblF.out'
#os.system(cmd10)

cmd11 = 'blastp -db uniprot_sprot.fasta -query '+Sp+'_sigORFs.fasta -out '+Sp+'_sigORFs.blastsprot.out -outfmt 6 -evalue 1E-10 -max_target_seqs 1 -num_threads 12'
#os.system(cmd11)


# Compile new datatable
def readNIfasta(filename):
    seqs = {}
    reprs = {}
    infile = open(filename, 'r')
    for line in infile:
        line=line.rstrip()
        if line.startswith('>'):
            ID=line[1:].split('|')[0]
            reprs[ID] = line[len(ID)+2:]
            seqs[ID] = infile.next().rstrip()
    infile.close()
    return seqs, reprs

def readTABDtext(filename):
    records = []
    infile = open(filename, 'r')
    for line in infile:
        line = line.rstrip()
        if line[0] != '#':
            HMMER = line.split()
            if '_dtblF.out' in filename:#HMMER domains
                records.append([HMMER[0], HMMER[3], HMMER[4]])
            elif '_tblF.out' in filename:#HMMER targets
                records.append([HMMER[0], HMMER[2], HMMER[3]])
            elif 'blastsprot.out' in filename:# BLASTp SWISSPROT
                records.append([HMMER[0], HMMER[1], HMMER[2], HMMER[3], HMMER[-2]])
            else:
                print filename
    infile.close()
    return records

print '\nWriting summary results...'
#allseqs, allheads = readNIfasta(Sp+'.allORFs.fasta')
FinORFs, SpmTpms = readNIfasta(Sp+'_finalORFs.fasta')
SSs, SpmTpms2 = readNIfasta(Sp+'_SSeqs.fasta')

tHMMER = readTABDtext(Sp+'HMMER_output1_tblF.out')
tIDs = [item[0].split('|')[0] for item in tHMMER]

dHMMER = readTABDtext(Sp+'HMMER_output2_dtblF.out')
dIDs = [item[0].split('|')[0] for item in dHMMER]

SWISS = readTABDtext(Sp+'_sigORFs.blastsprot.out')
bIDs = [item[0].split('|')[0] for item in SWISS]
print 'BLAST records:', len(SWISS)

#allORFsdata = open('/home/clone/NEWVEXILLUM/ORFs/'+Sp+'.alldata', 'r')
allORFsdata = open(Sp+'.alldata', 'r')
newORFsummary = {}
alreadyseen = []
checkset = set([item.split('_')[0] for item in FinORFs.keys()])
print 'Final ORFS:', len(checkset), FinORFs.keys()[0]
for line in allORFsdata:
    line = line.rstrip()
    oldata = line.split('\t')
    ORFid = oldata[0]
    if ORFid in checkset and not ORFid in alreadyseen:
        #newdata = ORFid+'\t'+SpmTpms[ORFid]+'\t'+SSs[ORFid]+'\t'+oldata[4]+'\t'+oldata[5]
        newdata = '\t'.join(oldata[:4]+[SSs[ORFid]]+oldata[4:])
        if ORFid in tIDs:#add HMMER target annotation
            ind = tIDs.index(ORFid)
            newdata = newdata+'\t'+tHMMER[ind][1]+'\t'+tHMMER[ind][2]
        else:
            newdata = newdata+'\t'+'nohit'+'\t'+'nohit'
        if ORFid in dIDs:#add HMMER domain annotation
            ind1 = dIDs.index(ORFid)
            newdata = newdata+'\t'+dHMMER[ind1][1]+'\t'+dHMMER[ind1][2]
        else:
            newdata = newdata+'\t'+'nohit'+'\t'+'nohit'
        if ORFid in bIDs:#add BLASTp against uniprot SWISS annotation
            ind2 = bIDs.index(ORFid)
            newdata = newdata+'\t'+SWISS[ind2][1]+'\t'+SWISS[ind2][2]+'\t'+SWISS[ind2][3]+'\t'+SWISS[ind2][4]
        else:
            newdata = newdata+'\t'+'nohit'+'\t'+'nohit'+'\t'+'nohit'+'\t'+'nohit'
        
        newORFsummary[ORFid] = newdata
        alreadyseen.append(ORFid)
allORFsdata.close()
print 'final ORFS:', len(newORFsummary)

newORFsdata = open(Sp+'_secreted_ORFs.alldata', 'w')
sortedORFs = sorted(newORFsummary.keys())
#print >>newORFsdata, 'shortID\tSpms_and_tpms\tAAseqs\tSignalSeq\tNucleotideSeq\tHMMERtarget\tHMMERtID\tHMMERdomain\tHMMERdID\tSportID\tBLAST_PID\tBLAST_len\tBLASTe-value'
print >>newORFsdata, 'shortID\tOldID\tContigID\tSpms_and_tpms\tSignalSeq\tAAseqs\tNucleotideSeq\tHMMERtarget\tHMMERtID\tHMMERdomain\tHMMERdID\tSportID\tBLAST_PID\tBLAST_len\tBLASTe-value'
for thing in sortedORFs:
    print >>newORFsdata, newORFsummary[thing]
newORFsdata.close()
