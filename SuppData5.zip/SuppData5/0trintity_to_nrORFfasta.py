import sys, os
"""
USAGE:

Predict ORFs
 V
Rename ORFs (in both AA and NT versions) and build a non-redundant ORF list for each species.
Write two separate outputs:
1. a tab-delimited txt file with all information per ORF
2. a fasta with non-redundant list of ORFs
New header:
>SpNUM|dataset:tpm|dataset2:tpm...
"""

def rewriteExpr(samples, tpms):
    outstr = ''
    for i in range(len(samples)):
        s = samples[i]+':'+str(tpms[i])+'|'
        outstr = outstr+s
    return outstr[:-1], sum(tpms)

#Sp = sys.argv[1]
#1. Predict ORFs
filelist = os.listdir('.')
premaster = []

thing = 'Cvirgo_secreted_transcripts.fasta'
Sp = thing.split('_')[0]
dataset = Sp
cmd1='./ORFfinder -in '+thing+' -g 1 -s 0 -ml 90 -out '+dataset+'.ORFs.fasta -outfmt 0 2>ORFerr'
#os.system(cmd1)
cmd2='./ORFfinder -in '+thing+' -g 1 -s 0 -ml 90 -out '+dataset+'.ntORFs.fasta -outfmt 1 2>ORFerr'
#os.system(cmd2)
cmd3 = 'python makesomethingNotInterleaved.py '+dataset+'.ORFs.fasta '+dataset+'.NIORFs.fasta'
#os.system(cmd3)
cmd4 = 'python makesomethingNotInterleaved.py '+dataset+'.ntORFs.fasta '+dataset+'.ntNIORFs.fasta'
#os.system(cmd4)
cmd5 = 'rm *.ORFs.fasta *.ntORFs.fasta'
#os.system(cmd5)

expdata = {}
contigs = []
rfasta = open(thing, 'r')
for line in rfasta:
    line = line.strip()
    if line.startswith('>'):
        contigs.append(line[1:].split()[0])
        expdata[line[1:].split()[0]] = []
rfasta.close()

noseq = 0
dsets = ['SG', 'ASG', 'VGD', 'VGP']
for dataset in dsets: 
    print dataset       
    # read in expression data
    exp = open(dataset+'_quant.sf', 'r')
    exp.readline()
    for line in exp:
        expr = line.rstrip().split('\t')
        if expr[0] in contigs:
            expdata[expr[0]].append(float(expr[3].replace(',','.')))
    exp.close()
    
# read in ntORFs
ntORFs = open(Sp+'.ntNIORFs.fasta', 'r')
ntseqs = {}
for line in ntORFs:
    line=line.rstrip()
    if line.startswith('>'):
        ntORFID = line.split()[1]
        ntseqs[ntORFID] = ntORFs.next().strip()
ntORFs.close()
setnt = set(ntseqs.keys())
print dataset, len(ntseqs), 'ntORFs readin'

# read in ORFs
maxtpm = {}
estrings = {}
ORFs = open(Sp+'.NIORFs.fasta', 'r')
AAseqs = {}
for line in ORFs:
    line=line.rstrip()
    if line.startswith('>'):
        ORFID = line.split('|')[1].split()[0]
        if 'TRINITY' in ORFID:
            contigID = 'TRINITY'+ORFID.split('TRINITY')[1].split(':')[0]
        else:
            contigID = ORFID.split('_')[1].split(':')[0]
        if 'partial' in line:
            AAseqs[ORFID] = ORFs.next().strip()
        else:
            AAseqs[ORFID] = ORFs.next().strip()+'*'
        estring, sumexpr = rewriteExpr(dsets, expdata[contigID])
        if ORFID in setnt:
            dataline = [ORFID, contigID, estring, AAseqs[ORFID], ntseqs[ORFID]]
        else:
            dataline = [ORFID, contigID, estring, AAseqs[ORFID], 'noseq']
            noseq+=1
        maxtpm[ORFID] = sumexpr
        estrings[ORFID] = estring
        premaster.append(dataline)
ORFs.close()
print dataset, len(AAseqs), 'AAORFs readin\n'
print noseq, 'nt sequence missing'

#2. Merge ORFs & rewrite headers
"""
nrAAseqs = list(set([item[3] for item in premaster]))
print len(nrAAseqs), 'non-redundant AAORFs retrieved'
invertedORFs = {}
maxtpm = {}
for AA in nrAAseqs:
    invertedORFs[AA] = []
    maxtpm[AA] = 0
for entry in premaster:
    invertedORFs[entry[3]].append(entry[0]+':tpm-'+str(entry[2]))
    if entry[2] > maxtpm[entry[3]]:
        maxtpm[entry[3]] = entry[2]
"""
ORFasta = open(Sp+'.allORFs.fasta', 'w')
counter = 1
newIDs = {}
for key in sorted(maxtpm, key=maxtpm.get, reverse=True):
    newIDs[key] = Sp+str(counter).zfill(7)
    counter += 1
    if maxtpm[key] > 0:
        print >>ORFasta, '>'+newIDs[key]+'|'+estrings[key]+'\n'+AAseqs[key]
ORFasta.close() 
   
MASTER = open(Sp+'.alldata', 'w')

for entry in premaster:
    if maxtpm[entry[0]] > 0:
        print >>MASTER, newIDs[entry[0]]+'\t'+entry[0]+'\t'+entry[1]+'\t'+entry[2]+'\t'+entry[3]+'\t'+entry[4]
MASTER.close()










