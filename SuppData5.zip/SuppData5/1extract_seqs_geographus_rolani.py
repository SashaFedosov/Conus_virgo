# -*- coding: utf-8 -*-
"""
Created on Thu May 25 17:30:39 2023

@author: Sasha
"""

import sys, os
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio.Alphabet import generic_dna
from Bio.Alphabet import IUPAC
from Bio.Blast import NCBIXML

"""
FUNCTIONS
"""

def translate_upstream(NTseq, bNTseq):
    AAseq = bNTseq.translate()
    for i in [0,1,2]:
        fAAseq = NTseq[i:].translate()
        if AAseq in fAAseq:
            break
    return fAAseq

def alignfAA(fAA, bAA):
    st = '-'*fAA.index(bAA)
    endstring = '-'*(len(fAA)-len(bAA+st))
    nbaa = st+bAA+endstring
    return nbaa

def trimfAA2(fAA, bAA):
    stAA = str(fAA)
    if bAA[0] == 'M':
        startstring = ''
    else:
        startstring = stAA[:fAA.index(bAA)]
        if '*' in startstring:
            startstring = stAA[:fAA.index(bAA)].split('*')[-1]
        if 'M' in startstring:
            startstring = 'M'+'M'.join(startstring.split('M')[1:])
    endstring = str(fAA[fAA.index(bAA)+len(bAA):]).split('*')[0]
    return startstring+bAA+endstring 

def HD(seq1, seq2):#two seqs of equal length
    HD = 0
    for i in range(len(seq1)):
        if seq1[i] != seq2[i]:
            HD+=1
    return HD

def HDalign(lseq, sseq):
    HDs = []
    for j in range(len(lseq)-len(sseq)+1):
        HDs.append(HD(lseq[j:j+len(sseq)], sseq))
    return min(HDs)
        
    
"""
SCRIPT
"""
dset = 'rolani'
maxPID = 1

rblast = open('D:\\virgo\\'+dset+'.blastout', 'r')
wblast = open('D:\\virgo\\'+dset+'_filtered.out', 'w')
IDs = []
hits = {}
ph = {}
PIDs = {}
for line in rblast:
    line = line.strip()
    data = line.split('\t')
    gooddata = False
    if float(data[2]) >= 55 and not data[0] in IDs and 'Conus' in data[1] and not 'W-superfamily' in data[1] and not 'Z-superfamily' in data[1] and int(data[3]) >= 35:
        gooddata = True
    if float(data[2]) >= 50 and not data[0] in IDs and 'Profundiconus' in data[1] and not 'W-superfamily' in data[1] and not 'Z-superfamily' in data[1] and int(data[3]) >= 35:
        gooddata = True
    if float(data[2]) >= 55 and 'Cvirgo' in data[1] and not data[0] in IDs and int(data[3]) >= 35:
        gooddata = True
    if gooddata == True:
        IDs.append(data[0])
        hits[data[0]] = [int(data[6]),int(data[7])]
        ph[data[0]] = data[1]
        PIDs[data[0]] = data[2]
        print >>wblast, line
rblast.close()
wblast.close()

print len(IDs)
for thing in IDs[:5]:
    print thing, hits[thing]

seqs = {}
trinity = open('D:\\virgo\\'+dset+'_trinity.fasta', 'r')
for line in trinity:
    line= line.strip()
    if line.startswith('>'):
        ID = line[1:].split()[0]
        if ID in IDs:
            seqs[ID] = trinity.next().strip()
trinity.close()
print len(seqs)


AAs = []
alltrans = {}
#for k in [m for m in IDs[:50] if '-superfamily' in ph[m]]:
for k in IDs:
    if hits[k][0] < hits[k][1]:
        NTseq = Seq(seqs[k], IUPAC.unambiguous_dna)
        bNTseq = NTseq[hits[k][0]-1:hits[k][1]]
    else:
        NTseq = Seq(seqs[k], IUPAC.unambiguous_dna).reverse_complement()
        bNTseq = Seq(seqs[k][hits[k][1]-1:hits[k][0]], IUPAC.unambiguous_dna).reverse_complement()
        
    bAAseq = bNTseq.translate()
    #print k, bAAseq
    complete = False
    fAAseq = translate_upstream(NTseq, bNTseq)
    # Now if there is a stop upstream or downstream the BLASTED region, we trim the full seq and return the trimmed one
    #print bNTseq, bAAseq, hits[k]
    #print fAAseq
    AAseq = trimfAA2(fAAseq, bAAseq)
    alltrans[k] = [str(bNTseq),str(bAAseq),str(fAAseq), str(AAseq)]
    AAs.append(str(AAseq))

     
lsortedAA = sorted(AAs, key=len, reverse=True)
nrAA = [lsortedAA[0]]
for i in range(1, len(lsortedAA)):
    nr = True
    for thing in nrAA:
        if HDalign(thing, lsortedAA[i]) <= maxPID*float(len(lsortedAA[i]))/100:
            nr = False
            print HDalign(thing, lsortedAA[i]), '-> discarded :-)'
            break
    if nr == True:
        nrAA.append(lsortedAA[i])
print len(AAs), len(nrAA)

AAf = open('D:\\virgo\\'+dset+'_filtered_seqs.txt', 'w') 
alreadyseen = []
for key in alltrans:
    if alltrans[key][-1] in nrAA and not alltrans[key][-1] in alreadyseen:
        alreadyseen.append(alltrans[key][-1])
        print >>AAf, key+'\t'+ph[key]+'\t'+ PIDs[key]+'\t'+alltrans[key][-1]+'\t'+alltrans[key][-2]
AAf.close()        
    
#   
    #print k+'\t'+ph[k]+'\t'+str(bNTseq)+'\t'+str(bAAseq)+'\t'+str(AAseq)
    #print >> AAf, k+'\t'+ph[k]+'\t'+str(bNTseq)+'\t'+str(bAAseq)+'\t'+str(AAseq)
#AAf.close()
    
    
    #print >>AAf, k+'\t'+hits[k]+'\t'+seqs[k]+'\t'+bNTseq+'\t'+


