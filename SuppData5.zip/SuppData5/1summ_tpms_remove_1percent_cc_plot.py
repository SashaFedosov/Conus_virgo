# -*- coding: utf-8 -*-
"""
Created on Thu Sep 07 00:09:40 2017

#xtracts and summarises tpm values for gene superfamilies

@author: Sasha
"""
import os, sys
import numpy as np
import matplotlib.pyplot as plt

try:
    f = open("E:\\Dropbox\\Conus_virgo\\virgodata\\Virgo_conopeptides_4tiss.txt", 'r')
except IOError:
    print "File datafile.fa does not exist"

gsfs = {}
for line in f:
    line = line.strip().replace(',','.')
    data = line.split('\t')
    tpms = [float(a) for a in data[:4]]
    dtpms = []
    for i in tpms:# Here we remove the records with tpm < 1% of the highest as putative contamination
        if i <= max(tpms)/100:
            dtpms.append(0)
        else:
            dtpms.append(i)
    
    if data[5] not in gsfs.keys():
        gsfs[data[5]] = dtpms
    else:
        for i in range(len(dtpms)):
            gsfs[data[5]][i] += float(dtpms[i])
f.close()

sums = [0,0,0,0]
for i in sorted(gsfs.keys()):
    print i, gsfs[i]
    for j in range(len(gsfs[i])):
        sums[j]+=gsfs[i][j]

outf = open('E:\\Dropbox\\Conus_virgo\\virgodata\\Virgo_conotoxins_relativeexpression.txt', 'w')
relgsfs = {}
for i in sorted(gsfs.keys()):
    relgsfs[i] = [str(gsfs[i][k]/sums[k]) for k in range(len(sums))]
    print >>outf, i+'\t'+'\t'.join(relgsfs[i])
outf.close()    
""" 
tissues = ['SG','ASG','VGD','VGP']

lgsfs = {}
for key in gsfs:
    lgsfs[key] = []
    for thing in gsfs[key]:
        if thing <10:
            lgsfs[key].append(float(0))
        else:
            lgsfs[key].append(np.log10(thing))

for i in sorted(gsfs.keys()):
    print i, lgsfs[i]

labels = []
sg = []
asg = []
vgp = []
vgd = []

#lbs = ['conotoxin', 'minor sf', 'other conopeptide', 'other venom component', 'enzyme']
for key in sorted(gsfs.keys()):
    labels.append(key)
    sg.append(lgsfs[key][0])
    asg.append(lgsfs[key][1])
    vgp.append(lgsfs[key][2])
    vgd.append(lgsfs[key][3])

superfamilies = range(1,len(gsfs)+1)
index = np.arange(len(superfamilies))
bar_width = 0.2
opacity = 0.8

rects1 = plt.bar(index, sg, alpha=opacity, width=0.2, color='#feb326', label='sg')
rects2 = plt.bar(index + bar_width, asg, alpha=opacity, width=0.2, color='#e84d8a', label='asg')
rects3 = plt.bar(index + bar_width*2, vgp, alpha=opacity, width=0.2, color='#64c5eb', label='vgd')
rects2 = plt.bar(index + bar_width*3, vgd, alpha=opacity, width=0.2, color='#7f58af', label='vgp')


#plt.xlabel('Gene superfamilies')
plt.xlabel('transcripts groups superfamilies')
plt.ylabel('log10 tpms')
#plt.title('Gene superfamily log10 expression')
plt.title('Other groups of venom peptides log10 expression')
plt.xticks(index + bar_width*1.5, labels, rotation = 45)#
plt.rc('xtick', labelsize=5)
plt.legend()
#my_dpi=96
#plt.figure(figsize=(2000/my_dpi, 1000/my_dpi), dpi=my_dpi) 
plt.grid(color = 'grey', linestyle = '--', linewidth = 0.5)
plt.tight_layout()
#plt.show()
#plt.savefig('E:\\Dropbox\\Conus_virgo\\Plots\\Fig1-4_other_venom_components_log10tpms.svg')
"""