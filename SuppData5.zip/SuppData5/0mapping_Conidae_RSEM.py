#!/usr/bin/env python


import os
import sys
import argparse
import multiprocessing


def get_args(): 
	parser = argparse.ArgumentParser(description="run novoalign")

	#forces required argument to let it run
	required = parser.add_argument_group("required arguments") 
	required.add_argument("--map", help="textfile with samples to run and what fasta file to match it to", required=True) 

	return parser.parse_args()

def align(element):

	ID = element
	
	r1name = '.R1.trimmed.fq'  #extension of front reads
	r2name = '.R2.trimmed.fq' #extension of back reads

# some names for input output files

	variables = dict(
	sample = ID,
	ref = ID + '.trinity.fasta',
	read1 = ID + r1name,
	read2 = ID + r2name
	) #name your output


	commands = """
	cp /home/clone/CONIDAE/{sample}/{read1} ./
	cp /home/clone/CONIDAE/{sample}/{read2} ./
	cp /home/clone/CONIDAE/{sample}/{ref} ./{ref}
	rsem-prepare-reference --bowtie2 {ref} {sample}
	rsem-calculate-expression --paired-end --bowtie2 -p 12 {read1} {read2} {sample} {sample}
	rm {read1} {read2}
	""".format(**variables)



	cmd_list = commands.split("\n")
	for cmd in cmd_list:
		os.system(cmd)
mylist = []
def main():
	args = get_args() 



	with open(args.map) as rfile:
		for line in rfile:
			line = line.strip()
			mylist.append(line)

	pool = multiprocessing.Pool(4)
	pool.map(align, mylist)#run the function with the arguments

if __name__ == "__main__": #run main over multiple processors
	main()
